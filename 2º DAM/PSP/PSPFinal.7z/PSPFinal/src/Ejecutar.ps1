﻿cd ~;cd 'C:\Program Files\Java\jdk1.8.0_191\bin'; .\javac.exe 'C:\Users\sergi\Desktop\Proyectos\PSPFinal\src\Ejecutar.java'
echo hola > C:\Users\sergi\Desktop\Proyectos\PSPFinal\src\prueba1.txt
start-sleep -seconds 5
cd ~;cd 'C:\Users\sergi\Desktop\Proyectos\PSPFinal\src'; java Ejecutar >  res.txt
