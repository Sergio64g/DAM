import Ventanas.Splash;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Splash splash = new Splash();
        splash.lanzar();


    }
}
