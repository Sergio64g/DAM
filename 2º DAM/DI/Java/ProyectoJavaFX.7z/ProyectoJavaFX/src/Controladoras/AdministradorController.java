package Controladoras;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class AdministradorController implements Initializable {
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
