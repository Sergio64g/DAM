import Utils.*;
import Ventanas.Splash;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import org.w3c.dom.ls.LSOutput;

public class Main {
    public static void main(String[] args) {
        Splash splash = new Splash();
        splash.lanzar();


    }
}
